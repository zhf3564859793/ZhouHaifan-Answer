import torch
import torch.nn as nn
from torch.nn.modules.activation import ReLU
from torch.nn.modules.conv import Conv2d
from torch.nn.modules.linear import Linear
import torch.optim as optim
import torch.functional as F
import os
from torchvision import datasets,transforms
from PIL import Image
from torch.utils.data import Dataset,DataLoader
import numpy as np
#设置超参数
batch_size=16#每次塞给网络的数据量
epoch_num=10#一共遍历多少轮
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  #用GPU训练，还是CPU训练
learning_rate=1e-2
#数据转换为张量形式并归一化
data_transform=transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=0.1307, std = 0.3081)
])
class MyData(Dataset):
    def __init__(self,image_path,label_path,transform):
        super(MyData,self).__init__()
        self.image_path=image_path
        self.label_path=label_path
        self.images=os.listdir(image_path)
        self.labels = open(label_path, 'r').read().splitlines()
        self.transform=transform
    def __len__(self):
        return len(self.images)
    def __getitem__(self, index):
        # load image
        img_name = str(index)+".png"
        img_name = os.path.join(self.image_path, img_name)
        img = Image.open(img_name)
        img = self.transform(img)   #调用数据预处理函数
        label = int(self.labels[index])  
        return img, label
# data path
train_image_path = "D:\深度学习上机练习/MNIST/train-images"
train_label_path = "D:\深度学习上机练习/MNIST/train-labels.txt"
test_image_path = "D:\深度学习上机练习/MNIST/t10k-images"
test_label_path = "D:\深度学习上机练习/MNIST/t10k-labels.txt"
training_data = MyData(train_image_path, train_label_path, data_transform)
test_data = MyData(test_image_path, test_label_path, data_transform)
# 创建 DataLoader，分批次加载数据
train_dataloader = DataLoader(training_data, batch_size=batch_size, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=1)
print(len(train_dataloader))   # len(training_data) / batch_size
print(len(training_data))
#构建卷积神经网络
class CNNNet(nn.Module):
    def __init__(self):
        super(CNNNet,self).__init__()
        self.convs=nn.Sequential(
            nn.Conv2d(1,16,3,stride=1, padding=1),#第一层卷积层：输入（1通道，28*28）[Batch_size， 1, 28,  28],经过3*3的卷积核以及填充，输出（16通道，28*28）[Batch_size，16, 28,  28]
            nn.ReLU(),
            nn.MaxPool2d(2,2),#第一层池化层，输入 [Batch_size， 16, 28,  28], 输出  [Batch_size，16, 14,  14]
            nn.Conv2d(16,32,3,stride=1,padding=1),#第二层卷积层：输入（16通道，14*14）[Batch_size， 16, 14,  14],经过3*3的卷积核以及填充，输出（32通道，14*14）[Batch_size，32, 14,  14]
            nn.ReLU(),
            nn.MaxPool2d(2,2)#第二层池化层，输入 [Batch_size， 32, 14,  14], 输出  [Batch_size，32, 7,  7]
        )
        self.fcs=nn.Sequential(
            nn.Linear(1568,512),# 输入 [Batch_size， 32*7*7], 输出  [Batch_size，512]
            nn.ReLU(),
            nn.Linear(512,256),
            nn.ReLU(),
            nn.Linear(256,128),
            nn.ReLU(),
            nn.Linear(128,10)
        )
    def forward(self,x):
        x=self.convs(x)
        x=x.view(-1,1568)
        x=self.fcs(x)
        return x
model = CNNNet().to(device)  #创建模型，并部署到cpu/gpu上
optimizer = optim.SGD(model.parameters(), lr=learning_rate)    #用于更新模型参数，找到最好的参数值
loss_f = torch.nn.CrossEntropyLoss()    # 多分类任务用 交叉熵损失函数
def train(dataloader, model, loss_f, optimizer):
    size = len(dataloader.dataset)   
    model.train()   
    for iteration, (im, label) in enumerate(dataloader):
        im, label = im.to(device), label.to(device)
        
        # 前向传播
        pre = model(im)   #模型预测 prediction
        loss = loss_f(pre, label)   #计算损失函数
        
        # 后向传播 （Backpropagation）：固定的3个步骤
        optimizer.zero_grad()   # 优化器置零
        loss.backward()        # 后向传播
        optimizer.step()       # 参数更新

        if iteration % 100 == 0:
            loss, current = loss.item(), iteration * len(im)
            print("loss: %.4f, current:%5d/size:%5d" %(loss, current, size))
    return loss
def test(dataloader, model, loss_f):
    size = len(dataloader.dataset)
    model.eval()  #evaluation
    test_loss, correct = 0, 0
    with torch.no_grad():
        for im, label in dataloader:
            im, label = im.to(device), label.to(device)
            pre = model(im)
            test_loss += loss_f(pre, label).item()
            pre_class = pre.argmax(dim=1)
            correct += (pre_class == label).type(torch.float).sum().item()
    test_loss /= size
    correct /= size
    print("Test\n  Accuracy: %.1f,  Average loss:%.8fd \n" %(100*correct, test_loss))
    return test_loss, correct
train_loss_all = np.zeros(epoch_num)
test_loss_all = np.zeros(epoch_num)
correct_all = np.zeros(epoch_num)
for t in range(epoch_num):
    print(f"Epoch {t}\n-------------------------------")
    train_loss_all[t] = train(train_dataloader, model, loss_f, optimizer)
    test_loss_all[t], correct_all[t]  = test(test_dataloader, model,loss_f)
print("Done!")
import matplotlib.pyplot as plt
epoches = np.arange(1, epoch_num+1, 1)
plt.figure()  # 添加一个窗口。如果只显示一个窗口，可以省略该句。
plt.plot(epoches, train_loss_all, '-g*')  # plot在一个figure窗口中添加一个图，绘制曲线，默认颜色
plt.plot(epoches, test_loss_all, '-r*')  
plt.figure()  # 添加一个窗口
plt.plot(epoches, correct_all, '-r*') 

